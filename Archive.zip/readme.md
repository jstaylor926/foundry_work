# Establish Domain Model
# Define Object Types
# Specify Properties and Value Types
# Define Link Types
# Layer in Metadata and Governance
# Iteratively enhance with derived properties and actions


Steps to implement
1. Import the YAML
2. Ingest sample tasks
3. verify link traversal
4. iterate and enhance


